import React from 'react';
import Sicilia from './Sicilia';
function App() {
  return  <main>
    <section className="container">
      <Sicilia/>
    </section>
  </main>
}

export default App;